package com.example.demo.application;

import com.example.demo.domain.model.Produto;
import com.example.demo.domain.ports.ProdutoRepositoryPort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProdutoService {

    private final ProdutoRepositoryPort repository;

    public ProdutoService(ProdutoRepositoryPort repository) {
        this.repository = repository;
    }

    public Produto criarProduto(Produto produto) {
        return repository.salvar(produto);
    }

    public List<Produto> listarProdutos() {
        return repository.listarTodos();
    }

    public Optional<Produto> buscarPorId(Long id) {
        return repository.buscarPorId(id);
    }

    public void deletarProduto(Long id) {
        repository.deletar(id);
    }
}
