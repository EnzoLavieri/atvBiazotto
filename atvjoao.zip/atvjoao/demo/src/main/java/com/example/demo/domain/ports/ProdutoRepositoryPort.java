package com.example.demo.domain.ports;

import com.example.demo.domain.model.Produto;
import java.util.List;
import java.util.Optional;

public interface ProdutoRepositoryPort {
    Produto salvar(Produto produto);
    List<Produto> listarTodos();
    Optional<Produto> buscarPorId(Long id);
    void deletar(Long id);
}
