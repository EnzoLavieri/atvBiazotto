package com.example.demo.adapter.repository;

import com.example.demo.domain.model.Produto;
import com.example.demo.domain.ports.ProdutoRepositoryPort;
import com.example.demo.infrastructure.entity.ProdutoEntity;
import com.example.demo.infrastructure.repository.ProdutoJpaRepository;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class ProdutoRepositoryAdapter implements ProdutoRepositoryPort {

    private final ProdutoJpaRepository jpaRepository;

    public ProdutoRepositoryAdapter(ProdutoJpaRepository jpaRepository) {
        this.jpaRepository = jpaRepository;
    }

    private ProdutoEntity toEntity(Produto produto) {
        ProdutoEntity entity = new ProdutoEntity();
        entity.setId(produto.getId());
        entity.setNome(produto.getNome());
        entity.setPreco(produto.getPreco());
        return entity;
    }

    private Produto toDomain(ProdutoEntity entity) {
        return new Produto(entity.getId(), entity.getNome(), entity.getPreco());
    }

    @Override
    public Produto salvar(Produto produto) {
        ProdutoEntity saved = jpaRepository.save(toEntity(produto));
        return toDomain(saved);
    }

    @Override
    public List<Produto> listarTodos() {
        return jpaRepository.findAll().stream().map(this::toDomain).collect(Collectors.toList());
    }

    @Override
    public Optional<Produto> buscarPorId(Long id) {
        return jpaRepository.findById(id).map(this::toDomain);
    }

    @Override
    public void deletar(Long id) {
        jpaRepository.deleteById(id);
    }
}
